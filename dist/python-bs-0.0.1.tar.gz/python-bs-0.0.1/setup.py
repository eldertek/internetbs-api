import os
from setuptools import setup, find_packages

version = os.getenv('VERSION')

setup(
    name='python-bs',
    version=version,
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
    ],
)
